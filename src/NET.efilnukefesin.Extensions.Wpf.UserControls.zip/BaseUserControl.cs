﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NET.efilnukefesin.Extensions.Wpf.UserControls
{
    public class BaseUserControl : UserControl
    {
        //TODO: reactivate / implement
        #region Properties

        //#region BoundDataContextProperty: the data context which can be bound now
        ///// <summary>
        ///// the data context which can be bound now
        ///// </summary>
        //public static readonly DependencyProperty BoundDataContextProperty = DependencyProperty.Register("BoundDataContext", typeof(object), typeof(BaseUserControl), new PropertyMetadata(null, BaseUserControl.onBoundDataContextChanged));
        //#endregion BoundDataContextProperty

        #endregion Properties

        #region Construction

        //public BaseUserControl()
        //{
        //    this.InitializeComponent();
        //    this.SetBinding(BoundDataContextProperty, new Binding());
        //}

        #endregion Construction

        #region Methods

        #region onBoundDataContextChanged
        ///// <summary>
        ///// e.NewValue is your new DataContext
        ///// </summary>
        ///// <param name="d">the concrete UserControl instance</param>
        ///// <param name="e">e.NewValue is the new DataContext</param>
        //protected static abstract void onBoundDataContextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        //{
        //    // e.NewValue is your new DataContext
        //    // d is your UserControl

        //}
        #endregion onBoundDataContextChanged

        #endregion Methods
    }
}
